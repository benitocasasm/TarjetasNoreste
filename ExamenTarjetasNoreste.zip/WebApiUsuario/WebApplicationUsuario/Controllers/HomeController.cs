﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WebApiUsuario.Models;
using WebApplicationUsuario.Helper;
using WebApplicationUsuario.Models;

namespace WebApplicationUsuario.Controllers
{
    public class HomeController : Controller
    {
        UsuarioApi _api = new UsuarioApi();
        public async Task<IActionResult> Index()
        {
            List<Usuario> usuario = new List<Usuario>();
            HttpClient client = _api.Initial();
            HttpResponseMessage res = await client.GetAsync("api/Usuario");
            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                usuario = JsonConvert.DeserializeObject<List<Usuario>>(result);
            }

            return View(usuario);
        }
        
        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
