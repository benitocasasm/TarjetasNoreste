﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApiUsuario.Data;
using WebApiUsuario.Models;

namespace WebApiUsuario.Controllers
{

    [Route("api/[controller]")]
    public class UsuarioController : Controller
    {
        private Context _context;

        public UsuarioController(Context context)
        {
            _context = context;

        }

        [httpGet]
        public List<Usuario> Get()
        {

            return _context.Usuarios.ToList();
        }

        public IActionResult Index()
        {
            return View();
        }
    }

    internal class httpGetAttribute : Attribute
    {
    }
}